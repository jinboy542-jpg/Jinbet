# RonoTrade Sports Betting Demo

A mobile-friendly sports betting homepage inspired by common sportsbook layouts.

## Included
- Responsive RonoTrade homepage
- Football match cards
- Odds selection
- Interactive betting slip
- Combined odds and potential return calculator
- Demo Login/Sign Up buttons
- No real-money betting functionality

## Deploy
Upload `index.html` to GitHub and import the repository into Vercel.

## Next
Connect Supabase Authentication and a secure backend. Real-money betting requires the applicable gambling licence, age/KYC controls, responsible-gambling measures, and compliant payment processing.
